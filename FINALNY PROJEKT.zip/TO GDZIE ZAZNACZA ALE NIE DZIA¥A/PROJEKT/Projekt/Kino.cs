﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    public enum EnumBilety
    {
        biletuglowy = 20,
        biletnormalny = 25,
        biletuglowyowocoweczwartki = 15,
        biletnormalnyowocoweczwartki = 20
    }
}/*
    public class Kino
    {
        string nazwa;
        List<Sala> miejsca = new List<Sala>();

        public string Nazwa { get => nazwa; set => nazwa = value; }
        public List<Sala> Miejsca { get => miejsca; set => miejsca = value; }

        public Kino(string nazwa, List<Sala> miejsca)
        {
            Nazwa = nazwa;
            Miejsca = miejsca;
        }
    }
}*/
